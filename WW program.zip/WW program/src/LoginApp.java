import javax.swing.*;
import java.awt.*;
import java.io.IOException;

public class LoginApp extends JFrame {
    public LoginApp() {


       
        JFrame frame;
        frame= new JFrame(); 
        frame.setTitle("VWatching.com");
        ImageIcon logo=new ImageIcon("roar.jpg");
        frame.setIconImage(logo.getImage());
        frame.getContentPane().setBackground(new Color(143,143,143));
        frame.setLocationRelativeTo(null);

        JLabel headingLabel = new JLabel("<html><b><h1 style='color:grey;'>Welcome to Wallet Watching!!</h1><b></html>");
        headingLabel.setFont(new Font("Arial", Font.ROMAN_BASELINE, 20));
        headingLabel.setBounds(200,10, 979, 60); 
        headingLabel.setHorizontalAlignment(SwingConstants.CENTER);

        frame.add(headingLabel);




         //collage Logo
         ImageIcon clglogo=new ImageIcon("ww.jpg");
         Image iclglogo=clglogo.getImage();
         Image resizedImg=iclglogo.getScaledInstance(1300,700,Image.SCALE_SMOOTH);
         ImageIcon reclglogo=new ImageIcon(resizedImg);
         JLabel img=new JLabel(reclglogo);
         img.setBorder(BorderFactory.createLineBorder(Color.BLACK,3));

         img.setBounds(135,100,1300,700);
         frame.getContentPane().add(img);

        frame.revalidate();
        frame.repaint();


        //frame defalut functionalities
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
        frame.setExtendedState(JFrame.MAXIMIZED_BOTH);
        frame.setSize(screenSize);
        frame.setLayout(null);
        frame.setVisible(true);

    }

    public static void main(String[] args)  throws IOException, InterruptedException
     {
        SwingUtilities.invokeLater(() -> {
        

        try{
            while(true)
            {
                String user=JOptionPane.showInputDialog(null, "<html><b><h4 style='color:grey;font-family:Comic Sans MS;'>Enter user name:</h></b></html>","vWHome",JOptionPane.OK_CANCEL_OPTION);
                if(user.equals("admin")){
                        String psw=JOptionPane.showInputDialog(null, "<html><b><h4 style='color:grey;font-family:Comic Sans MS;'>Enter Password:</h></b></html>","vWHome",JOptionPane.OK_CANCEL_OPTION);
                        if(psw==null) break;
                        else if(psw.equals("123456"))
                        {
                            JOptionPane.showMessageDialog(null,"<html><b><h4 style='color:grey;font-family:Comic Sans MS;'>Welcome User!!</h></b></html>","vWHome",JOptionPane.INFORMATION_MESSAGE);
                            new LoginApp().setVisible(true);
                            break;
                        }
                        else{JOptionPane.showMessageDialog(null,"<html><b><h4 style='color:grey;font-family:Comic Sans MS;'>Incorrect Password</h></b></html>","vWHome",JOptionPane.ERROR_MESSAGE);}
                }
                else
                {
                    JOptionPane.showMessageDialog(null,"<html><b><h4 style='color:grey;font-family:Comic Sans MS;'>Incorrect Username</h></b></html>","vWHome",JOptionPane.ERROR_MESSAGE);

                }
            }
        }
        catch(Exception e)
        {
            JOptionPane.showMessageDialog(null,"<html><b><h4 style='color:grey;font-family:Comic Sans MS;'>Sorry</h></b></html>","vWHome",JOptionPane.INFORMATION_MESSAGE);
        }
    });
        }
    }

